# 路径穿越 / 本地文件包含（迁移重建最小版）

> **来源说明：** 迁移前的身份包缺这一篇，但 `SKILL.md`、`README.md`、`打穿短表.md`（4 处）、`info-leak-test.md` §21、`cloud-ide-codex-rce-chain.md` 共 8 处指向它。本文件按这些指针**归并重建为最小可用版**，只覆盖被点名的几节，不是原专篇全文。现场以证据为准，不替代 `rules/dig-scope-workflow.md` §4 的进站打法。
> 写不写、定几级只认 `rules/vuln-report-format.md`；半条链、只读到公开静态、占位口令都不算成。

## 认什么 → 打哪（速查）

| 认什么 | 打哪 | 出什么算成 | 假点 |
|--------|------|------------|------|
| 站上有 `/static` `/assets` `/img` `/files` 静态前缀；或 Caddy 模板吃用户输入 | `/static../` 读 web 根外文件；Caddy 模板试 `{{readFile "path"}}` | 读到 `nginx.conf` / 应用配置 / 密钥文件 | 只 404；只能列静态目录里本来就有的文件；Caddy 不执行用户输入 |
| Node 把仓库根交给 koa-static / express.static（能直接 GET 到 `package.json` 或 `routes/`） | 不登录打 `/config/online.yml`、`/config/default.yml`、`/config/production.yml`；有 `package.json` 就顺着 node-config 环境名扫 | yml/json 里是**完整库账密或云密钥实值** | 静态根只出 public；yml 没有账密；`package.json` 200 但 config 404 |
| 对象存储 / 静态桶上的旧 .NET 发布物；aspx 源码还能 GET，同目录 `web.config` 被 WAF 拦 | `web.config` 456 别停，打同目录 `App.config`、`*.exe.config`、`bin/*.dll.config` | 完整账密或 DeveloperToken，不是占位串 | aspx 200 但 config 404；只有源码没有钥；`ENTER_YOUR_PASSWORD` 一类占位 |
| 公网 `:8009` AJP（Ghostcat） | 读 `/WEB-INF/web.xml`，再跟配置 / class | 读到 `web.xml` / class 里的实值 | `secretRequired`；端口不是 AJP |
| 公网 VS Code / code-server 类无登录墙 | 读容器 `environ` / 进程环境变量 | 云钥、集群凭证等实值 | 只出版本号；环境变量全是占位 |

## 1. Nginx alias 缺斜杠 / 静态前缀穿越

`location /static { alias /var/www/assets; }`（alias 末尾少斜杠）时，`/static../` 可越出目标目录。先确认命中的是真 alias 而非 `root`，再逐级试编码（`%2e%2e%2f`、双写、`..%2f`）与换位置（path / query）。Caddy 模板另走 `{{readFile "path"}}`，先对照一个必然存在的公开文件确认模板真执行。

**假点：** 只 404；能列的仅是本就公开的静态文件；模板把输入当纯文本渲染。

## 2. 仓库根当静态（node-config）

GET 得到 `package.json` 即说明静态根指向仓库根。按 node-config 的环境名顺序（`default` → `development` / `production` / `online` → `{HOSTNAME}`）扫 `config/*.yml|json|js`。**只有出现完整账密或云密钥实值才算成**；抄到 host 没密码按 `rules/src-value-hunting.md` §2 继续找凭据，不单独成篇。

## 3. 静态桶上的 .NET 发布物

`web.config` 被 WAF 拦（常见 456）不等于没有同目录兄弟文件。`App.config`、`*.exe.config`、`bin/*.dll.config` 往往绕过同一条规则且带连接串。占位串（`ENTER_YOUR_PASSWORD`、`xxx`）不算。

## 21. AJP / Ghostcat 读 WEB-INF

对应 `info-leak-test.md` §21 的指针。确认 `:8009` 是 AJP 而非 HTTP 再打；读到 `web.xml` 只是入口，继续跟配置里的账密 / class 反编译，别停在「能读 web.xml」。

## 通用升链（别停在能读能下）

文件通道开了 → 立刻转业务 API / 完整账密 / 云钥 / 可执行链（`rules/src-value-hunting.md` §2）。抄到凭证必须过 `rules/vuln-report-format.md` 的**认钥闸**（假值对照生产认了，且认钥枪带出身份或列表）才能落报告。中危同一对象先升链再换站。

## 假点

- 只出自己刚传的、公开静态、占位口令。
- 半条链、只能列表不能读正文、报错里猜路径没验证。
- 只在某个 host 的死 path 上成立（单站备忘，按 `rules/hunt-iter.md` 不进短表）。
