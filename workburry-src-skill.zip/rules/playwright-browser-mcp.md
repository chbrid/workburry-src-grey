# 浏览器控制：优先 Playwright MCP（永久）

> 本规则每个会话生效。WorkBuddy 的浏览器交互走 MCP，不用 shell 拼脚本驱动浏览器。

## 适用

以下场景**必须**用浏览器工具，不用 `npx playwright` 脚本、裸 CDP 连接，也不要把静态抓取当作交互控制：

- 打开 / 控制真实浏览器；点击、输入、滚动、填表、提交
- 页面快照 / 实时 UI 截图
- 改动后验证 UI、多步 Web 流程
- 需要 JS 渲染或登录态才能取到的内容
- 由页面生成 PDF、浏览器侧 QA / 冒烟检查

## 怎么调

1. 先确认 `playwright` MCP 已配置并启用（模板见包根 `mcp.json.template`，落到 `~/.workbuddy/mcp.json`）。
2. WorkBuddy 的 MCP 工具以 `mcp__<server>__<tool>` 形式出现；若当前会话没加载，先用工具检索能力找到对应工具并读它的参数说明再调用，不要凭记忆猜参数。
3. 常用动作：`browser_navigate` / `browser_snapshot` / `browser_click` / `browser_type` / `browser_take_screenshot`。理解页面结构优先用无障碍快照，只有需要视觉核验才截图。
4. 多步任务保持同一浏览器会话，不要反复重启。

## 不适用

- 公开 URL 的纯静态抓取、无交互 → 内置网页抓取 / 搜索即可。
- 本地文件编辑、git、终端、代码分析 → 内置工具。
- `playwright` MCP 未配置、未授权或被禁用 → 明确说明不可用并降级，不要偷偷换成 shell 驱动浏览器。

## 自检

- [ ] 是否先确认了 MCP 可用？
- [ ] 实际交互是否走的浏览器工具，而不是 bash 一行流？
- [ ] 结构理解是否优先用了快照？

## 会话预期

`mcp.json.template` 里的 `playwright` 项默认启用，通过 `bin/playwright-dual-slot.mjs` 占 9222 / 9223 双槽之一，供多个窗口并行。把它当一等工具路径，不是每次需要手动重开的插件。
