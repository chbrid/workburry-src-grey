# src-hunt — WorkBuddy 身份覆盖包

把一套调教好的「黑盒 SRC 挖洞 + 白盒 0day 审计」Agent 人格、纪律、知识库与 MCP 工具，打包成 WorkBuddy 可直接安装的技能包。由 Grok 版 `clown-src-6k-skill` 迁移而来，**原包未做任何改动**。

> 目录名 `workburry-src-skill` 沿用你指定的拼写；产品名统一写作 **WorkBuddy**。技能名为 `src-hunt`。

## 目录结构

```
workburry-src-skill/                 ← 包根 = skill 根
├── SKILL.md                        ← 技能入口（name: src-hunt，触发词 + 路由表）
├── AGENTS.md                       ← 全局规则总览 / 最短执行备忘
├── README.md                       ← 本文件
├── 安装清单.md                     ← 人读的安装对照表
├── 给朋友的提示词.txt              ← 让接收方 WorkBuddy 自动安装的整段提示词
├── mcp.json.template               ← MCP 配置模板（fofa + playwright）
├── rules/                          ← 12 篇永久规则（1700+ 行，纪律中枢）
├── references/                     ← 51 篇实战知识（打穿短表 + 47 篇专题 + 报告样例 + 证据固定 / 副作用清理，约 1.6 万行）
├── bin/playwright-dual-slot.mjs    ← 9222/9223 双槽 Chrome CDP 启动器
├── mcp-servers/fofa_MCP/           ← FOFA 检索 MCP（FastMCP + stdio）
├── docs/迁移说明.md                ← 与 Grok 版的逐项差异、已修复缺陷
└── identity/工作背景.md            ← 可选补充段，默认不安装
```

## 两种用法

1. **自己装**：按 `安装清单.md` 手动复制并写 `~/.workbuddy/mcp.json`。
2. **发给朋友**：把整个文件夹（或 zip）连同 `给朋友的提示词.txt` 里的整段文字一起发过去，对方粘进 WorkBuddy 对话即可自动安装。

安装后的形态：整个包成为 `~/.workbuddy/skills/src-hunt/`，用户级 `MEMORY.md` 追加一行指针，MCP 配置合并进 `~/.workbuddy/mcp.json`。

## 路径约定（重要）

包内所有 `rules/xxx.md`、`references/xxx.md` **一律相对 skill 根解析**，不是相对当前文件。规则正文里沿用「知识库」一词时，指的就是 `references/`。

补充三条，避免误判为断链：

- 规则正文里的**裸文件名**（如 `vuln-report-format.md`、`hunt-iter.md`）指 `rules/` 下同名文件。
- `references/` 内「见 `xxx.md`」指该目录内同名文件；指向规则时写 `rules/xxx.md`。
- 文档里出现的 `xxx.md` 是占位示例，不是真实引用。

## 与原 Grok 版的差异（摘要）

| 项 | 变化 |
|----|------|
| 安装目标 | `%USERPROFILE%\.grok\` → `~/.workbuddy/skills/src-hunt/` |
| 配置格式 | `config.toml`（TOML）→ `mcp.json`（JSON） |
| 规则引用 | 绝对 `~/.grok/rules/` → 包根相对 `rules/` |
| 知识库 | `skills/skill/知识库/` → `references/` |
| 技能名 | `skill` → `src-hunt` |
| 27 篇 Grok user-guide | **不迁移**（Grok 专属，含误导性配置指引） |
| 浏览器工具调用 | 去掉 Grok 的 `search_tool`/`use_tool`，改 WorkBuddy MCP 工具方式 |

完整对照、四项缺陷修复说明见 `docs/迁移说明.md`。

## 四项已修复缺陷

1. `fofa_dual.ps1` 的硬编码 FOFA 凭据 → 改为只读环境变量；旧版凭据建议按已泄露处理并轮换。
2. `rules/researcher-blackbox-whitebox.md` 被覆盖损坏的开头 → 重建。
3. 8 处引用但缺失的 `path-traversal-lfi-test.md` → 补建最小版（已标注为重建、非原文）。
4. `fofa_MCP/README.md` 技术栈写错（FastAPI / 不存在的 LICENSE）→ 重写。

**方法论正文（规则与知识库）除路径字符串外原样保留**：未删条、未改矮「算成」条件、未动 CORS 不挖 / 禁开越狱教材 / 禁止登出用户会话 / 认钥闸等安全边界与优先级链。

## 报告与写操作口径（对齐 TRAE 版，2026-11-14）

按用户要求，把两处口径改成与 `trae-src-chn01-skill` 一致，**授权模式与凭据总口径保持本包原样**（不引入 TRAE 的 `MODE: self/strict` 开关）。

| 项 | 改前（Grok 原版） | 改后（对齐 TRAE） |
|---|---|---|
| 报告结构 | 两张表：版式 + 8 块 / 落不落 | **六段式 + 三附录 + A1–A10 出 / B1–B10 不出决策表 + §5 定级口径** |
| 出报告门槛 | 中危 / 高危 / 严重，低危不写 | **能过 SRC 审核的低危及以上**；信息级只进负结果附录 |
| 写操作 | 先添加 → 删自己加的；改密/改绑过了立刻改回 | **只证明接口接受参数 + 字段变化即停**，不做落库验证，不做「改回即安全」假设 |
| 双账号例外 | 无独立条款 | `rules/write-operation-discipline.md` §3：四条前置 + 回读校验 + 留痕 + 声明残留 |

- `rules/vuln-report-format.md` 重写为六段式；落盘路径仍用本包的 `Desktop\{任务}_SRC挖洞\报告\`，不用 TRAE 的 `recon/<目标>/`。原包的**匿名闸 / 认钥闸 / 整包格式 / 报告管理**作为 §7、§8 保留，A10 的判定仍依赖认钥闸。
- 新增 `rules/write-operation-discipline.md` 作为写操作唯一权威条款（L0–L4 动作分级、禁止登出、禁止真资损/批量），共 12 篇规则。
- `SKILL.md`、`AGENTS.md`、`src-value-hunting.md`、`dig-scope-workflow.md`、`hunt-iter.md` 及 `references/` 里 30 处旧表述已替换；`hunt-iter` 的迭代门槛改指新 format 的 §2 / §5。
- `references/打穿短表.md` 4 处「算成」按新纪律收口（不再要求落库验证），`authbypass-test.md` / `idor-test.md` 的「改回」动作链作废。

## 安全与依赖

- 包内 `.env` 是空模板，**不含任何真实凭据**；`mcp.json.template` 的 env 值全空。Key 由使用者自己填。
- 不覆盖 `SOUL.md` / `IDENTITY.md` / `USER.md`；`identity/` 里的补充段默认不安装。
- 需要 `uv`（fofa MCP）与 `node`（playwright MCP）。**本包不自动安装任何依赖**，缺哪个就报告对应 MCP 暂不可用。
- 合并 `mcp.json` 时保留原有其它 server，不整文件覆盖。

## 自检

- [ ] `rules/` 15 篇、`references/` 52 个 md（含 README）齐全
- [ ] 无 `~/.grok` / `config.toml` / `Grok` 残留
- [ ] 无 32 位明文凭据残留
- [ ] `references/README.md` 清单里的文件全部存在
- [ ] `mcp.json.template` 是合法 JSON 且 env 全空
