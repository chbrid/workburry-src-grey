# FOFA 资产搜索 MCP（WorkBuddy 版）

stdio MCP server，基于 `mcp` 的 FastMCP + `httpx`，Python 3.12。**不是 FastAPI，不监听端口**，由 WorkBuddy 按 `mcp.json` 拉起并通过标准输入输出通信。

## 能力

| 暴露项 | 说明 |
|--------|------|
| 工具 `get_alerts` | 按 `domain` / `ip` / `port` / `host` / `body` / `icon_hash` / `icp` / `status_code` 组合查询 FOFA `/api/v1/search/all`，默认取 `host,ip,port`，`size=100` |
| 提示词 `search_prompt` | 生成带资产上下文的分析提示词 |

三账号（primary → backup → backup2）遇 429 / 820041 / 日上限自动切换，**已限流的账号直接排除、不再重试**；403 视为鉴权问题而非限流。换号规则见 `fofa.py` 的 `_is_rate_limited`。异常与回显统一经 `_scrub()` 去掉 `key=` / `email=` 值，避免凭据进入工具返回与对话上下文（见 `rules/credential-policy.md` §6）。

## 依赖

见 `pyproject.toml` / `uv.lock`：`httpx`、`python-dotenv`、`mcp`（带动 `starlette`、`uvicorn`、`pydantic` 等传递依赖，共 36 个包）。在目录内执行 `uv sync` 安装，无需手动 `pip install`。

## 配置

Key 只放 `~/.workbuddy/mcp.json` 的 `mcpServers.fofa.env`，或本目录 `.env`（空模板，格式见 `.env.example`）。完整模板在包根 `mcp.json.template`，账号说明见 `fofa_accounts.md`。

启动命令由 `mcp.json` 给出，形如：

```
uv run --directory <包安装路径>/mcp-servers/fofa_MCP python fofa.py
```

## 安全

- 只在授权范围内检索，遵守 FOFA API 使用条款。
- 凭据不进对话、不进报告、不进知识库、不写死在脚本里。
- 请求构造默认带 `status_code=200`；要捞非 200 资产时把该参数传空字符串。
