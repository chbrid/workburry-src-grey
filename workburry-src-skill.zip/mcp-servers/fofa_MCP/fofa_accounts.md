# FOFA 三账号（挖洞用）

策略：**优先主号** → 遇 429 / 请求频繁 / 820041 / 日上限 → **自动切备用1** → 再用 **备用2**。

| 角色 | 环境变量 | 备注 |
|------|----------|------|
| 主号 primary | `FOFA_EMAIL` + `FOFA_KEY` | 默认先走 |
| 备用 backup | `FOFA_KEY_BACKUP`（email 可空） | 只传 key 也能用 |
| 备用2 backup2 | `FOFA_EMAIL_BACKUP2` + `FOFA_KEY_BACKUP2` | 前两个用尽才用 |

**Key 只写在 `~/.workbuddy/mcp.json` 的 `mcpServers.fofa.env` 或本目录 `.env`（本包内是空模板）。凭据总口径以 `rules/credential-policy.md` 为准。** 不要抄进对话 / skill / references / 报告；**任何脚本文件都不得硬编码 Key**。

## 配置位置

- `~/.workbuddy/mcp.json` → `mcpServers.fofa.env`（模板见包根 `mcp.json.template`）
- `mcp-servers/fofa_MCP/.env`（可选；`fofa.py` 通过 python-dotenv 读取，见 `.env.example`）
- 切换逻辑：`fofa.py` 内 `_account_list` + `_exhausted` + `_is_rate_limited`
- PowerShell 备用脚本 `fofa_dual.ps1` 只从环境变量读凭据

## curl 备用（MCP 未热加载时）

主号 / 备用1 / 备用2 分别用对应 email+key 调 `https://fofa.info/api/v1/search/all`。限流换下一个，不要空撞。

## 注意

- 改 env 后需**重启 fofa MCP / 新开会话**才进进程；未重启时可用 curl 手切。
- 三个都限流 → 停 FOFA，挖已入库（认 `rules/dig-scope-workflow.md` §2.1.4）。
- 拷到新机后：把 `mcp.json.template` 里的路径改成新机实际路径，自己填三套 Key。
- **从旧版身份包迁移时**：旧版 `fofa_dual.ps1` 曾含硬编码凭据，若那台机器用过该版本，按已泄露处理并轮换；本包已清除。
